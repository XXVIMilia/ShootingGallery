from subclass import socketTest
from subclass import rfBLE
import json
import serial

myJetson = serial.Serial("/dev/ttyACM0",9600)



myRF = rfBLE.rfInterface()
mySock = socketTest.unityWebSock()



def setUpProg():
    mySock.awaitConn()
    incoming = myJetson.read()
    positions = json.load(incoming.decode())
    mySock.configGame(positions)



def mainloop():
    try:
        while(1):
            Newevent = mySock.read()
            if(Newevent == "hit"):
                IDstr = mySock.read()
                toWrite = myRF.duinoID[int(IDstr)]
                myRF.duino(toWrite)
                myRF.sendMessage("01")
            elif(Newevent == "clean"):
                IDstr = mySock.read()
                toWrite = myRF.duinoID[int(IDstr)]
                myRF.duino(toWrite)
                myRF.sendMessage("00")
    except KeyboardInterrupt:
        mySock.closeSock()
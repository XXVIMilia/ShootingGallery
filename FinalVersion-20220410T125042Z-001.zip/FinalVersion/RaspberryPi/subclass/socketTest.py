from http import client
import socket
import time

class unityWebSock:



    backlog = 1
    size = 1024
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)

    def __init__(self):
        self.s.bind(("10.108.49.34",50001))
        self.s.listen(self.backlog)


    

    def awaitConn(self):
        try:
            print("Waiting RN")
            self.myclient, self.address = self.s.accept()
            print("Client joined: " + self.address[0])
        except OSError:
            print("Something Goofed, try again")
            self.myclient.close()
            self.s.shutdown(socket.SHUT_RDWR)
            self.s.close()

    def configGame(self,myPos):
        self.write("config")
        for target in myPos:
            name = target[1]
            coord = str(target[1])
            self.write(name)
            self.write(coord)

            

    def write(self, value):
        self.myclient.send(value.encode("UTF-8"))
                

    def read(self):
        data = self.myclient.recv(self.size)
        if(data):
            print(data)
            return(data)

    def closeSock(self):
        self.write("Quit")
        self.myclient.close()
        self.s.shutdown(socket.SHUT_RDWR)
        self.s.close()
        



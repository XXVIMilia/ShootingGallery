import RPi.GPIO as GPIO
import time
import spidev
from lib_nrf24 import lib_nrf24

class rfInterface():
    duinoID = [0x77, 0x78, 0x79, 0x80, 0x81, 0x82, 0x83, 0x84]
    pipes = [[0xE0, 0xE0, 0xF1, 0xF1, 0xE0], [0xF1, 0xF1, 0xF0, 0xF0, 0xE0]]

    def __init__(self):
        GPIO.setmode(GPIO.BCM)
        self.radio = lib_nrf24.NRF24(GPIO, spidev.SpiDev())
        self.radio.begin(0, 25)
        self.radio.setPayloadSize(2)
        self.radio.setDataRate(self.radio.BR_1MBPS)
        self.radio.setPALevel(self.radio.PA_MIN)
        self.radio.setAutoAck(True)
        self.radio.enableDynamicPayloads()
        self.radio.enableAckPayload()
        self.radio.openWritingPipe(self.pipes[0])
        self.radio.printDetails()


    def duino(self,outgoingID):
        channel = self.duinoID[outgoingID]
        self.radio.setChannel(channel)

    def sendMessage(self,data):
        sendMessage = list(data)
        while len(sendMessage) < 32:
            sendMessage.append(0)

        while True:
            start = time.time()
            self.radio.write(sendMessage)
            print("Sent the message: {}".format(sendMessage))
            self.radio.startListening()

            while not self.radio.available(0):
                time.sleep(1/100)
                if time.time() - start > 2:
                    print("Timed out.")
                break

            self.radio.stopListening()
            time.sleep(3)
using System.Collections;
using System.Collections.Generic;
using System;
using System.Threading;
using UnityEngine;
using System.IO;
using System.Net.Sockets;




public class testSocket : MonoBehaviour
{
    string desktopIP = "10.104.242.163";
    public string pi = "10.108.49.34";
    bool socketReady = false;
    int port = 50001;
    TcpClient mySocket;
    public NetworkStream theStream;
    StreamWriter theWriter;
    StreamReader theReader;
    // Start is called before the first frame update
    void Start()
    {
        setupsocket();           
    }

    public void setupsocket()
    {
        try
        {
            Debug.Log("Creating Client");
            mySocket = new TcpClient(pi, port);
            Debug.Log("Creating Stream");
            theStream = mySocket.GetStream();
            Debug.Log("Creating Writer");
            theWriter = new StreamWriter(theStream);
            Debug.Log("Creating Reader");
            theReader = new StreamReader(theStream);
            socketReady = true;
        }
        catch (Exception e)
        {
            Debug.Log("Socket Error " + e);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (!socketReady)
        {
            Debug.Log("Socket not ready!");
            return;
        }
        while (theStream.DataAvailable)
        {
            string dataFromPI = readFromSocket();
            Debug.Log("From the pi: " + dataFromPI);
            if(dataFromPI == "Quit")
            {
                closeSocket();
            }
            //theWriter.WriteLine("Get Fucked");
            //theWriter.Flush();
        }


    }

    public string readFromSocket()
    {
        if (!socketReady)
        {
            Debug.Log("Cant Read from socket, not ready!");
            return "";
        }


        string temp = theReader.ReadLine();
        return temp;    
   
    }

    public void writeToSocket(string data)
    {
        if (!socketReady)
        {
            Debug.Log("Cant write to socket, not ready!");
            return;
        }


        theWriter.Write(data);
        theWriter.Flush();

    }


    public void closeSocket()
    {
        if (!socketReady)
        {
            Debug.Log("Cant close, not ready to begin with!");
            return;
        }
        theWriter.Close();
        theReader.Close();
        mySocket.Close();
        socketReady = false;
    }
}

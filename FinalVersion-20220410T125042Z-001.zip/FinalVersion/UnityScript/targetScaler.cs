using System.Collections;
using System.Collections.Generic;
using UnityEngine;




public class targetScaler : MonoBehaviour
{
    public GameObject myself;
    public float scalingFactor;
    float xSc;
    float ySc;
    public float maxYPos;
    public float minYPos;
    // Start is called before the first frame update
    void Start()
    {
        xSc = 2.26f;
        ySc = 1.68f;
        maxYPos = 25;
        minYPos = 5;
        scalingFactor = 0.25f;
        myself.transform.localScale = new Vector3(2.26f, 1.0f, 1.68f);

    }

    // Update is called once per frame
    void Update()
    {

        float inputPos = ExtensionMethods.mapFloat(myself.transform.localPosition.y, minYPos, 0, maxYPos, 1);
        float xScaled = ExtensionMethods.mapFloat(inputPos,0, xSc , 1, xSc *scalingFactor);
        float yScaled = ExtensionMethods.mapFloat(inputPos, 0, ySc , 1, ySc * scalingFactor);

        myself.transform.localScale = new Vector3(xScaled, 1.0f, yScaled);
    }




    

}
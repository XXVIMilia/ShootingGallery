using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class ExtensionMethods
{

    public static float mapFloat(float value, float from1, float to1, float from2, float to2)
    {
        return (((value - from1) * (to2 - to1)) / (from2 - from1)) + to1;
    }

}
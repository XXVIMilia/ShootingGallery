using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity;




public class fingerGun : MonoBehaviour
{

    public LeapServiceProvider LeapController;
 
    bool hit;
    // Start is called before the first frame update
    void Start()
    {
        hit = false;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
  
        if (LeapController != null)
        {
            Leap.Frame frame = LeapController.CurrentFrame;

            if(frame.Hands.Count > 0)
            {
                List<Leap.Hand> hands = frame.Hands;
                foreach(Leap.Hand myHand in hands)
                {
                    Leap.Finger index = myHand.GetIndex();
                    Vector3 Laser = index.Direction.ToVector3();
                    Vector3 Pos = index.TipPosition.ToVector3();
                    bool physHit = Physics.Raycast(Pos, Laser);

                    if (physHit)
                    {
                        if (!hit)
                        {
                            hit = true;
                            Debug.Log("Hit Detected!");
                        }
                    }
                    else
                    {
                        hit = false;
                    }

                }
            }
           
        }
        
    }
}

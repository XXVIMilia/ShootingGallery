import cv2
import numpy as np
from matplotlib import pyplot as plt
import re
import json
import serial


def detectColor():#will comvert an RGB image to HSV to allow for color detection
    global imgOG
    img = cv2.imread("Pictures/laser.png")
    imgOG = img
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    #cv2.imshow("greenMask", imgOG)
    #cv2.waitKey(0)   
    mask = cv2.inRange(hsv,(55, 0,0), (140,255,255))

    imask = mask>0

    green=np.zeros_like(img, np.uint8)
    green[imask] = img[imask]

    cv2.imwrite("Pictures/cyanHSV.png", green)

def getCenter(coords):#returns the center point of my given coordinates
    points = [list([int(z) for z in x.strip().split()]) for x in re.findall(r"\[\[([^-\[\]]+)\]\]", coords)]
    #print(f"Points cleaned: {points}")
    #print(f"Center of points: {centeroidpython(points)}")
    return(centeroidpython(points))

def centeroidpython(data): #returns a center point of a given area 
    x, y = zip(*data)
    l = len(x)
    return sum(x) / l, sum(y) / l

def getOutline(coords): #takes raw vertex data and cleans it to provide corner vertexs
    points = [list([int(z) for z in x.strip().split()]) for x in re.findall(r"\[\[([^-\[\]]+)\]\]", coords)]
    #print(f"Points cleaned: {points}")
    return(points)

global x
global y


def mask(roi): #Creates a mask to identify color and returns given color of object
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    red1 = cv2.inRange(hsv,(0, 50,20), (5,255,255)) #this is the red DONE
    red2 = cv2.inRange(hsv,(175, 50,20), (180,255,255))
    red = cv2.bitwise_or(red1, red2)
    if cv2.countNonZero(red)>3: #all red objects
        print("There is red")
        #cv2.imshow("redMask", red)
        #cv2.waitKey(0)
        return("Red")
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    green1 = cv2.inRange(hsv,(40, 50,20), (60,255,255)) #this is the green DONE
    green2 = cv2.inRange(hsv,(45, 50,20), (60,255,255))
    green = cv2.bitwise_or(green1, green2)
    if cv2.countNonZero(green)>3:#all green objects
        print("There is green")
        #cv2.imshow("greenMask", green)
        #cv2.waitKey(0)
        return("Green")
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV) #all yellow objects
    yel1 = cv2.inRange(hsv,(15, 50,20), (25,255,255)) #this is the yellow DONE
    yel2 = cv2.inRange(hsv,(15, 50,20), (25,255,255))
    yel = cv2.bitwise_or(yel1, yel2)
    if cv2.countNonZero(yel)>3:
        print("There is yel")
        return("yellow")
    else:
        return("Blue") #if none of the above return blue



def inner(coords): #provides the coordinates of all my angles to recreate new rectangles
    listx=[]
    listy=[]
    exterior =getOutline(coords)
    if len(exterior) > 2:
        for j in range(len(exterior)):
            listx.append(int(exterior[j][0]))
        listx.sort()
        print("this is sorted")
        listx.sort()
        print(listx)

        for j in range(len(exterior)):
            listy.append(int(exterior[j][1]))
        listy.sort()
        print("this is sorted")
        listy.sort()
        print(listy)

        if listx[-1] - listx[0] > 39:
            if listy[-1]-listy[0] > 39:
                print("actual square")
                roi=imgOG[listy[0]:listy[-1], listx[0]:listx[-1]]
                #cv2.imshow('wow', roi)
                #cv2.waitKey(0)
                color = mask(roi)
                return(color)


def detectShape(): #this function finds all the shapes in the enttire HSV image
    img = cv2.imread('Pictures/cyanHSV.png')
  
    # converting image into grayscale image
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite("Pictures/greyRect.png", gray)
    # setting threshold of gray image
    _, threshold = cv2.threshold(gray, 10, 255, cv2.THRESH_BINARY_INV)

    ##Fill in holes
    des = cv2.bitwise_not(threshold)
    contour,hier = cv2.findContours(des,cv2.RETR_CCOMP,cv2.CHAIN_APPROX_SIMPLE)
    for cnt in contour:
        cv2.drawContours(des,[cnt],0,255,-1)
    outt = cv2.bitwise_not(des)
    threshed = cv2.bitwise_not(outt)
    cnts = cv2.findContours(threshed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    canvas  = img.copy()
    contouredd= cv2.drawContours(canvas, cnts, -1, (0,255,0), 1)

    ## sort and choose the largest contour
    cnts = sorted(cnts, key = cv2.contourArea)
    allCenter=[]
    for j in range(1,len(cnts)): #this control how many coordinates get returned
        ## approx the contour, so the get the corner points
        arclen = cv2.arcLength(cnts[-j], True)
        approx = cv2.approxPolyDP(cnts[-j], 0.02* arclen, True)
        cv2.drawContours(canvas, [cnts[-j]], -1, (255,0,0), 1, cv2.LINE_AA)
        cv2.drawContours(canvas, [approx], -1, (0, 0, 255), 1, cv2.LINE_AA)
        color = inner(str(approx)) #use this to identify which object is which by its LED color

        centers = getCenter(str(approx))#function to get center point of box
        if color != None:
            allCenter.append(centers)
            allCenter.append(color)
    print("################################################")
    print(allCenter)
    #now we are going to aggregate data to send to Unity via serial
    outGoing = json.dump(allCenter)
    mySer =  serial.Serial("/dev/ttyACM0", 9600)
    mySer.write(outGoing.encode("UTF-8"))
    mySer.close()
    ## Ok, you can see the result as tag(6)
    # cv2.imshow('finalOut', contouredd)
    # cv2.waitKey(0)
    cv2.imwrite("Pictures/detected.png", canvas)
detectColor()
detectShape()